package it.miglioramentoReportTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import it.miglioramentoReportTest.function.FunzioniUtili;
import it.miglioramentoReportTest.model.ReportTest;
import it.miglioramentoReportTest.model.TabellaReport;



//NB: è necessario che il file di test sia del tipo:
// nomeTest_Hooks_release_1_0.java
//Dove: nomeTest è facoltativo
//		Hooks, deve essere presente se il test utilizza localizzatori Hooks
//		release_, deve essere presente, seguita dalla versione della release di creazione (per esempio 1_0)


@SpringBootApplication
public class MiglioramentoReportTestApplication {

	
	
	
	//Da linea di comando bisogna passare come args[0] la directory all'interno della quale si trovano i report .xls
	//Mettere (senza estenzione .xls) in args[1] il nome del report complessivo xls da generare
	public static void main(String[] args) throws IOException {
		SpringApplication.run(MiglioramentoReportTestApplication.class, args);
		
		
		final Boolean DEBUGGING = false;
		
		TabellaReport tabella = new TabellaReport();
		FunzioniUtili funzioni = new FunzioniUtili();
		
		
		
		
		
		String releaseDiCreazione = new String();
		String locatoreUtilizzato = new String();
		String esitoVerify_Hooks = "-";
		String causaFallimento = "-";
		


		//---------------------------------------------------------------------------
		//REPORT DA XML
		//String input_for_args0 = "D:\\CorsoSPRING\\AreaDiLavoro\\miglioramentoReportTest\\src\\main\\resources\\reportFiles";
		//Oppure String input_for_args0 = "D:\CorsoSPRING\AreaDiLavoro\catalogoProdottiBoot\target\surefire-reports";
		File directoryReportInput = new File(args[0]); 
		LinkedList<File> listaReportInput = new LinkedList<File>();
		listaReportInput = funzioni.findAllFilesInFolder(directoryReportInput,"xls");
				
		System.out.println("Vediamo lista file .xls presenti in directory di riferimento");
		int iteraz = 1;
		
		LinkedList<ReportTest> listReport = new LinkedList<>();
		
		for(File file: listaReportInput) {
			System.out.println("File numero "+iteraz+"!");
			System.out.println(file);
			
			//Aggiungiamo un seperatore riga tra i vari file
			ReportTest rt = new ReportTest();
			rt.setEsitoTest("");
			rt.setNomeTestSuite("File numero "+iteraz);
			listReport.add(rt);
			iteraz++;
			
			//ReportTest report = new ReportTest();
			
			//lettura di ogni singolo file dalla lista
			try {
			    POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(file));
			    HSSFWorkbook wb = new HSSFWorkbook(fs);
			    HSSFSheet sheet = wb.getSheetAt(0);
			    HSSFRow row;
			    HSSFCell cell;

			    int rows; // No of rows
			    rows = sheet.getPhysicalNumberOfRows();

			    int cols = 0; // No of columns
			    int tmp = 0;

			    // This trick ensures that we get the data properly even if it doesn't start from first few rows
			    for(int i = 0; i < 10 || i < rows; i++) {
			        row = sheet.getRow(i);
			        if(row != null) {
			            tmp = sheet.getRow(i).getPhysicalNumberOfCells();
			            if(tmp > cols) cols = tmp;
			        }
			    }

			    for(int r = 0; r < rows; r++) {
			        row = sheet.getRow(r);
			        if(row != null && r>0) {	//saltiamo la prima riga, si trovano gli header
			        	ReportTest report = new ReportTest();
			            for(int c = 0; c < cols; c++) {
			                cell = row.getCell((short)c);
			                if(cell != null) {
			                    // Your code here		            
			                	if(c==0) report.setNomeTestSuite(cell.getStringCellValue());
			                	if(c==1) report.setNomeTest(cell.getStringCellValue());
			                	if(c==2) report.setReleaseDiCreazione(cell.getStringCellValue());
			                	if(c==3) report.setLocatoreUtilizzato(cell.getStringCellValue());
			                	if(c==4) report.setEsitoTest(cell.getStringCellValue());
			                	if(c==5) report.setMsgEsitoTest(cell.getStringCellValue());
			                	if(c==6) report.setCausaRotturaTest(cell.getStringCellValue());
			                }
			            }
			            //Qui abbiamo un singolo report
			            //Aggiungiamo un report alla lista di report
			            listReport.add(report);
			            
			        }
			    }
			    
			} catch(Exception ioe) {
			    ioe.printStackTrace();
			}
			//Qui in listaReport abbiamo tutti i report del singolo file

		}
		
		//Qui in lista report ho i report di tutti i file
		tabella.setListaReport(listReport);
		funzioni.creaFileExcel(tabella, args[1]);

		
	}//chiude main

}//chiude classe file
